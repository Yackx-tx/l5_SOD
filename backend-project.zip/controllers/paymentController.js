const  Payment = require('../models/Payment');

// record payment (Insert)
exports.createPayment = async (req, res) => {
    try{
        const payment = new Payment(req.body);
        await payment.save();
        res.status(201).json(payment);
    } catch (error){
        res.status(400).json({ message:'Error recording payment', error: error.message });
    }
};

// get all payments (retrieving data)
exports.getAllPayments = async (req, res) => {
    try{
        const payments = await Payment.find().populate({ path: 'serviceRecordId', populate: [ { path: 'carId' }, { path: 'packageId'} ] });
        res.json(payments);
    } catch(error){
        res.status(500).json({ message: 'Error fetching payments', error: error.message })
    }
};
